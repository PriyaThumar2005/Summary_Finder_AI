from django.contrib import admin
from .models import QuestionAnswer

# Register your models here.
admin.site.register(QuestionAnswer)